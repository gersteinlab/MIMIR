# encoding:utf-8

configure = {
    ##baize && mutil-agent
    "azure":True,
    "open_ai_api_key": [""],  # openai api key list
    "open_ai_api_base": "",
    "key_bundles": [
            ('keyXXXX', "https://XXXX.openai.azure.com/"),
            ('keyXXXX', "https://XXXX.openai.azure.com/")],
    "memory_limit":10,


}
