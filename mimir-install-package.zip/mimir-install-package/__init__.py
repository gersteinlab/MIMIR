from pathlib import Path
DEFAULT_PROMPTSOURCE_CACHE_HOME = str(Path("~/.cache/talky").expanduser())
